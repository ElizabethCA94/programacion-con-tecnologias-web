Entrega # 2 

Incluye: 
HTML:

·       Menú de navegación con al menos 3 vistas.

·       Implementación de un formulario.

·       Elementos multimedia (mínimo 4).

·       Una tabla.

CSS:

·       La temática es libre, no obstante, se tendrá en cuenta la relación del contenido del sitio y los estilos.

·       Todos los elementos deben tener estilos realizados con CSS.

·       Se debe crear una animación con CSS.

·       Todos los CSS deben tener comentarios coherentes.

 

Git:

·       Se deben crear al menos 2 ramas, (teniendo en cuenta la principal).

·       En la rama secundaria deben verse los commit de los integrantes.

·       Deben asignar un responsable que administre el repositorio en su totalidad, de tal modo que sea el único en aceptar o rechazar los pull request.

·       El entregable será el enlace al repositorio en GitHub, el cual debe ser público.